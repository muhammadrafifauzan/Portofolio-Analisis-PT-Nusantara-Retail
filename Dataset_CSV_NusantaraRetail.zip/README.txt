=============================================================
  DATASET LATIHAN DATA ANALYST — PT NUSANTARA RETAIL (2023)
  Simulasi data perusahaan ritel B2B Indonesia
=============================================================

DAFTAR FILE CSV:
----------------

1. karyawan.csv (119 baris)
   Kolom: emp_id, nip, nama, departemen, jabatan, kota, tgl_masuk, gaji, status, lama_kerja_thn
   Latihan: RANK(), DENSE_RANK(), AVG() OVER PARTITION BY, LAG(tgl_masuk), XLOOKUP, INDEX-MATCH

2. produk.csv (30 baris)
   Kolom: kode_produk, nama_produk, kategori, harga_jual, hpp, margin, margin_pct, stok, status_stok
   Latihan: XLOOKUP cari harga by kode, FILTER by kategori, analisis margin

3. customer.csv (15 baris)
   Kolom: kode_customer, nama_perusahaan, industri, kota, nama_pic, email_pic,
          total_pembelian, jumlah_transaksi, avg_per_transaksi, tier
   Latihan: XLOOKUP, INDEX-MATCH 2-way, filter by tier

4. transaksi_penjualan.csv (840 baris)
   Kolom: id, no_transaksi, tanggal, tahun, bulan_num, bulan, hari, kuartal,
          kode_customer, nama_customer, industri_customer, kota_customer,
          kode_produk, nama_produk, kategori, qty, harga_satuan, hpp_satuan,
          total_penjualan, total_hpp, gross_profit, sales_nip, nama_sales, departemen_sales
   Latihan: ROW_NUMBER per customer, RANK per bulan, FILTER+SORT+UNIQUE, SUMPRODUCT

5. penjualan_harian.csv (365 baris)
   Kolom: tanggal, hari, bulan, kuartal, jumlah_transaksi, qty_terjual,
          total_penjualan, penjualan_kemarin, selisih, pct_perubahan,
          running_total, ma7_hari
   Latihan: LAG/LEAD, SUM() OVER (ROWS UNBOUNDED PRECEDING), Moving Average

6. target_sales.csv (48 baris)
   Kolom: bulan, no_bulan, kategori_produk, target, realisasi, pct_capaian,
          selisih, realisasi_bln_lalu, growth_mom_pct, status
   Latihan: LAG month-over-month, INDEX-MATCH lookup target, SUMPRODUCT kondisional

7. gaji_summary.csv (119 baris) — SUDAH ADA KOLOM SQL HASIL
   Kolom: nip, nama, departemen, jabatan, gaji, rank_gaji_dept, dense_rank_gaji_dept,
          avg_gaji_dept, max_gaji_dept, min_gaji_dept, selisih_dari_avg, pct_vs_avg, status_vs_avg
   Kegunaan: VERIFIKASI hasil query SQL kamu — bandingkan dengan kolom yang sudah ada

8. tren_penjualan_bulanan.csv (12 baris)
   Kolom: no_bulan, bulan, total_penjualan, total_transaksi, total_qty, gross_profit,
          penjualan_bln_lalu, selisih_mom, growth_mom_pct, running_total_ytd, avg_bulanan_ytd
   Latihan: LAG YoY/MoM, Running Total, analisis tren tahunan

9. performa_sales.csv (jumlah sales aktif)
   Kolom: rank_global, sales_nip, nama_sales, total_penjualan, jumlah_transaksi,
          total_qty, avg_per_transaksi, pct_dari_total_penjualan
   Latihan: RANK penjualan antar sales, DENSE_RANK, percentile

10. penjualan_per_kategori_bulan.csv (48 baris)
    Kolom: no_bulan, bulan, kategori, total_penjualan, jumlah_transaksi, total_qty,
           rank_kategori_bulan_ini, pct_dari_total_bulan
    Latihan: PARTITION BY kategori+bulan, ranking per periode

=============================================================
CARA IMPORT KE SQL (SQLite):
=============================================================

  .mode csv
  .headers on
  .import karyawan.csv karyawan
  .import transaksi_penjualan.csv transaksi_penjualan
  .import penjualan_harian.csv penjualan_harian

Atau via DB Browser for SQLite: File > Import > Table from CSV

=============================================================
CONTOH QUERY LANGSUNG BISA DICOBA:
=============================================================

-- 1. ROW_NUMBER per departemen
SELECT nip, nama, departemen, gaji,
  ROW_NUMBER() OVER (PARTITION BY departemen ORDER BY gaji DESC) AS urutan
FROM karyawan;

-- 2. RANK vs DENSE_RANK (bandingkan dengan gaji_summary.csv)
SELECT nip, nama, departemen, gaji,
  RANK() OVER (PARTITION BY departemen ORDER BY gaji DESC) AS rank_gaji,
  DENSE_RANK() OVER (PARTITION BY departemen ORDER BY gaji DESC) AS dense_rank
FROM karyawan;

-- 3. LAG - tren penjualan harian
SELECT tanggal, total_penjualan,
  LAG(total_penjualan) OVER (ORDER BY tanggal) AS kemarin,
  total_penjualan - LAG(total_penjualan) OVER (ORDER BY tanggal) AS selisih
FROM penjualan_harian;

-- 4. Running total manual (verifikasi dengan kolom running_total)
SELECT tanggal, total_penjualan,
  SUM(total_penjualan) OVER (ORDER BY tanggal ROWS UNBOUNDED PRECEDING) AS kumulatif
FROM penjualan_harian;

-- 5. Moving Average 7 hari (verifikasi dengan kolom ma7_hari)
SELECT tanggal, total_penjualan,
  ROUND(AVG(total_penjualan) OVER (ORDER BY tanggal ROWS 6 PRECEDING)) AS ma7
FROM penjualan_harian;

-- 6. Top 3 produk terlaris per kategori
SELECT * FROM (
  SELECT kategori, nama_produk,
    SUM(qty) AS total_qty,
    DENSE_RANK() OVER (PARTITION BY kategori ORDER BY SUM(qty) DESC) AS dr
  FROM transaksi_penjualan
  GROUP BY kategori, nama_produk
) t WHERE dr <= 3;

-- 7. Growth penjualan MoM per kategori (verifikasi dengan target_sales.csv)
SELECT bulan, kategori_produk, realisasi,
  LAG(realisasi) OVER (PARTITION BY kategori_produk ORDER BY no_bulan) AS bln_lalu,
  ROUND((realisasi - LAG(realisasi) OVER (PARTITION BY kategori_produk ORDER BY no_bulan))
    / LAG(realisasi) OVER (PARTITION BY kategori_produk ORDER BY no_bulan) * 100, 2) AS growth
FROM target_sales;

=============================================================
CATATAN KOLOM VERIFIKASI:
=============================================================
File gaji_summary.csv sudah berisi hasil RANK, DENSE_RANK, AVG yang benar.
File penjualan_harian.csv sudah berisi hasil LAG, running_total, MA7 yang benar.
File tren_penjualan_bulanan.csv sudah berisi MoM growth yang benar.
Gunakan file-file ini untuk MEMVERIFIKASI hasil query SQL kamu!
